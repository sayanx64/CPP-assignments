#include<iostream>

using namespace std;

int main(){
    string name;
    cout<<"Enter a name: "; 
    cin>>name;
    cout<<"Hello "<<name<<endl;
    return 0;
}