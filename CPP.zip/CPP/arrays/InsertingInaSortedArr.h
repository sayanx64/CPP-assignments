#pragma once
void jen(int &n, int A[<expr>], int x);

void disp(int n, int A[<expr>]);
