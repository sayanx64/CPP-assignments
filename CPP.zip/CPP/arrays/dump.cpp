// right shift

#include<stdio.h>
int main(){
    int x=10,y=2,z;
    z=x>>y;
    printf("%d",z);
    return 0;
}

// x in bin = 1010
// right shift 2 : 00000000