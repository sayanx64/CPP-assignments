#include<iostream>
using namespace std;



// int main(){
//     int n;
//     printf("Enter the array size: "); scanf("%d",&n);
//     int A[n];
//     printf("Enter %d elements: ",n);
//     for(int i = 0; i<n; i++){
//         scanf("%d",&A[i]);
//     }
//     printf("Peak elements are : ");
//     for(int i=1; i<n; i++){
//         if(A[i]>A[i-1] && A[i]>A[i+1]){
//             printf("%d ",A[i]);
//         }
//     }
//     return 0;
// }


