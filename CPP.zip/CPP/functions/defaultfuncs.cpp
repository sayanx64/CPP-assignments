#include<iostream>
using namespace std;

int add(int x, int y, int z=0){
    return x+y+z;
}


int main(){
    return 0;
}