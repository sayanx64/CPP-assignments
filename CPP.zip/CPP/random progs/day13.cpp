#include<stdio.h>
int main(){
    printf("HHEHEHEHE");
    return 0;
}