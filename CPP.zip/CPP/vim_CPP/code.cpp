#include<iostream>
using namespace std;
int main(){
    cout<<"This is shit"<<endl;
    return 0;
}

